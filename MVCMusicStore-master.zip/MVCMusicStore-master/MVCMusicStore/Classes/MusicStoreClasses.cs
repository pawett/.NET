﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCMusicStoreClasses
{
    public class Song
    {
        public string Title { get; set; }
        public string SongPath { get; set; }
    }

}