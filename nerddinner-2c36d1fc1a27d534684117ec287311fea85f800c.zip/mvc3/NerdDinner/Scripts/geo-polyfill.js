﻿function getCurrentLocation() {
    NerdDinner.getCurrentLocationByIpAddress();
}
